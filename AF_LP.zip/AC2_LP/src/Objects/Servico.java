/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objects;

/**
 *
 * @author alope
 */
public class Servico {
    private String nomeCliente;
    private String nomeFuncionario;
    private String endereco;
    private String cidade;
    private String uf;
    private String cep;
    private String servico;
    private String periocidade;
    private String descricao;
    private int     horas;
    
    public Servico(String nomeCliente, String nomeFuncionario, String endereco, String cidade, String uf, String cep, String servico, String periocidade, String descricao, int horas ){
        nomeCliente = this.nomeCliente;
        nomeFuncionario = this.nomeFuncionario;
        endereco = this.endereco;
        uf = this.uf;
        cep = this.cep;
        servico = this.servico;
        periocidade = this.periocidade;
        descricao = this.descricao;
        horas = this.horas;
    }
    public Servico(){}
    public void setnomeCliente(String nomeCliente){
        this.nomeCliente = nomeCliente;
    }
    public String getnomeCliente(){
        return(this.nomeCliente);
    }

    public void setnomeFuncionario(String nomeFuncionario){
        this.nomeFuncionario = nomeFuncionario;
    }
    public String getnomeFuncionario(){
        return(this.nomeFuncionario);
    }

    public void setendereco(String endereco){
        this.endereco = endereco;
    }
    public String getendereco(){
        return(this.endereco);
    }

    public void setcidade(String cidade){
        this.cidade = cidade;
    }
    public String getcidade(){
        return(this.cidade);
    }

    public void setUF(String uf){
        this.uf = uf;
    }
    public String getuf(){
        return(this.uf);
    }

    public void setcep(String cep){
        this.cep = cep;
    }
    public String getcep(){
        return(this.cep);
    }
    public void setservico(String servico){
        this.servico = servico;
    }
    public String getservico(){
        return(this.servico);
    }
    public void setperiocidade(String periocidade){
        this.periocidade = periocidade;
    }
    public String getperiocidade(){
        return(this.periocidade);
    }
    public void setdescricao(String descricao){
        this.descricao = descricao;
    }
    public String getdescricao(){
        return(this.descricao);
    }
    public void sethoras(int horas){
        this.horas = horas;
    }
    public int gethoras(){
        return(this.horas);
    }

    public void LimparCliente(){
        this.nomeCliente = " ";
        this.nomeFuncionario = " ";
        this.endereco = " ";
        this.cidade = " ";
        this.uf = " ";
        this.cep = " ";
        this.servico = " ";
        this.periocidade = " ";
        this.descricao = " ";
        this.horas = 0;
    }
    
}
