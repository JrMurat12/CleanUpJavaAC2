/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objects;

/**
 *
 * @author alope
 */
public class Cliente {
    private String nome;
    private String sexo;
    private String cpf;
    private String endereco;
    private String cidade;
    private String uf;
    private String cep;
    private String telefone;
    
    public Cliente(String nome, String sexo, String cpf, String endereco, String cidade, String uf, String cep, String telefone ){
        nome = this.nome;
        sexo = this.sexo;
        cpf = this.cpf;
        endereco = this.endereco;
        uf = this.uf;
        cep = this.cep;
        telefone = this.telefone;
    }
    public Cliente(){}
    public void setCPF(String CPF){
        this.cpf = cpf;
    }
    public String getCPF(){
        return(this.cpf);
    }

    public void setnome(String nome){
        this.nome = nome;
    }
    public String getnome(){
        return(this.nome);
    }

    public void setendereco(String endereco){
        this.endereco = endereco;
    }
    public String getendereco(){
        return(this.endereco);
    }

    public void setcidade(String cidade){
        this.cidade = cidade;
    }
    public String getcidade(){
        return(this.cidade);
    }

    public void setUF(String UF){
        this.uf = uf;
    }
    public String getUF(){
        return(this.uf);
    }

    public void setsexo(String sexo){
        this.sexo = sexo;
    }
    public String getsexo(){
        return(this.sexo);
    }
    public void setcep(String cep){
        this.cep = cep;
    }
    public String getcep(){
        return(this.cep);
    }
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    public String getTelefone(){
        return(this.telefone);
    }

    public void LimparCliente(){
        this.nome = " ";
        this.endereco = " ";
        this.cidade = " ";
        this.uf = " ";
        this.cpf = " ";
        this.sexo = " ";
    }
}

