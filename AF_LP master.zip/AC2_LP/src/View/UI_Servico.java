/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;
import Conexoes.MySQL;
import Objects.Servico;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
/**
 *
 * @author alope
 */
public class UI_Servico extends javax.swing.JFrame {
    MySQL conectar = new MySQL ();
    Servico novoServico = new Servico();
    /**
     * Creates new form UI_Servico
     */
    public UI_Servico() {
        initComponents();
        
        this.ListarEmpresas();
        this.ListarFuncionario();
    }
    private void ListarEmpresas (){
    this.conectar.conectaBanco();
    try {
            this.conectar.executarSQL(
            "SELECT "
            + "razaoSocial"
             + " FROM"
            + " empresa;"
            );
        while(this.conectar.getResultSet().next()) {
            cbxEmpresa.addItem(this.conectar.getResultSet().getString(1));
        }
        } catch (Exception e) {
            System.out.println("Erro ao consultar empresas: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar empresas!");
        
        } finally {
            this.conectar.fechaBanco();
        }
}
    
    private void ListarFuncionario (){
    this.conectar.conectaBanco();
    try {
            this.conectar.executarSQL(
            "SELECT "
            + "nome"
             + " FROM"
            + " funcionario;"
            );
        while(this.conectar.getResultSet().next()) {
            cbxFuncionario.addItem(this.conectar.getResultSet().getString(1));
        }
        } catch (Exception e) {
            System.out.println("Erro ao consultar funcionarios: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar funcionarios!");
        
        } finally {
            this.conectar.fechaBanco();
        }
}
    
    private void CadastrarServico(Servico novoServico){
        this.conectar.conectaBanco();
        
        novoServico.setnomeCliente((String)cbxEmpresa.getSelectedItem());
        novoServico.setnomeFuncionario((String)cbxFuncionario.getSelectedItem());
        novoServico.setservico((String)cbxServico.getSelectedItem());
        novoServico.sethoras(txtHoras.getText());
        novoServico.setdescricao(txtDescricao.getText());
    
    try {
                this.conectar.insertSQL ("INSERT INTO servico ("
                + "cliente, "
                + "funcionario, "
                + "tipoServico, "
                + "horas, "
                + "descricao "
            + ") VALUES ("
                + "'" + novoServico.getnomeCliente() + "',"
                + "'" + novoServico.getnomeFuncionario() + "',"
                + "'" + novoServico.getservico() + "',"
                + "'" + novoServico.gethoras() + "',"
                + "'" + novoServico.getdescricao() + "'"
            + ");");
            
            JOptionPane.showMessageDialog(null, "Servico cadastrado com sucesso");
        } catch (Exception e){
            System.out.println("Erro ao cadastrar servico " + e.getMessage());
        }
    }
    
    private void BuscarServico (Servico novoServico){
        this.conectar.conectaBanco();
        
        String consultaCnpj = this.txtConsultaServico.getText();
        
        try {
            this.conectar.executarSQL(
                    "SELECT "
                    + "cliente,"
                    + "funcionario,"
                    + "tipoServico,"
                    + "horas,"
                    + "descricao"
                    + " FROM"
                        + " servico"
                    + " WHERE"
                        + " funcionario LIKE '%" + consultaCnpj + "%'" + ";");
            while (this.conectar.getResultSet().next()){
                novoServico.setnomeCliente(this.conectar.getResultSet().getString(1));
                novoServico.setnomeFuncionario(this.conectar.getResultSet().getString(2));
                novoServico.setservico(this.conectar.getResultSet().getString(3));
                novoServico.sethoras(this.conectar.getResultSet().getString(4));
                novoServico.setdescricao(this.conectar.getResultSet().getString(5));
            }
            
            if(novoServico.getnomeFuncionario() == ""){
                JOptionPane.showMessageDialog(null, "Servico não encontrada!");
            }
        } catch (Exception e){
            System.out.println("Erro ao consultar servico " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar servico!");
        } finally{
            cbxEmpresa.setSelectedItem(novoServico.getnomeCliente());
            cbxFuncionario.setSelectedItem(novoServico.getnomeFuncionario());
            cbxServico.setSelectedItem(novoServico.getservico());
            txtHoras.setText(novoServico.gethoras());
            txtDescricao.setText(novoServico.getdescricao());
            this.conectar.fechaBanco();
        }
    }
    
    public void AtualizarServico(Servico novoServico){
        this.conectar.conectaBanco();
        
        String consultarServico = this.txtConsultaServico.getText();
        
        novoServico.setnomeCliente((String)cbxEmpresa.getSelectedItem());
        novoServico.setnomeFuncionario((String)cbxFuncionario.getSelectedItem());
        novoServico.setservico((String)cbxServico.getSelectedItem());
        novoServico.sethoras(txtHoras.getText());
        novoServico.setdescricao(txtDescricao.getText());
        
        try{
            this.conectar.updateSQL(
                    "UPDATE servico SET " + "cliente = " + "'" + novoServico.getnomeCliente() + "',"
                    + "funcionario = " + "'" + novoServico.getnomeFuncionario() + "',"
                    + "tipoServico = " + "'" + novoServico.getservico() + "',"
                    + "horas = " + "'" + novoServico.gethoras() + "',"
                    + "descricao = " + "'" + novoServico.getdescricao() + "'" 
                    + " WHERE " + "cliente LIKE '%" + consultarServico + "%'" + ";");
            JOptionPane.showMessageDialog(null, "Servico atualizado com sucesso");
                
        }catch (Exception e){
            System.out.println("Erro ao atualizar servico " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao atualizar empresa!");
        }finally{
            this.conectar.fechaBanco();
        }
    }
    
    public void DeletarServico(Servico novoServico){
        this.conectar.conectaBanco();
        
        String consultarNome = this.txtConsultaServico.getText();
        
        novoServico.setnomeCliente((String)cbxEmpresa.getSelectedItem());
        novoServico.setnomeFuncionario((String)cbxFuncionario.getSelectedItem());
        novoServico.setservico((String)cbxServico.getSelectedItem());
        novoServico.sethoras(txtHoras.getText());
        novoServico.setdescricao(txtDescricao.getText());
        
        try{
            this.conectar.deleteSQL(
                    "DELETE FROM servico WHERE " + "funcionario LIKE '%" + consultarNome + "%'" + ";");
            JOptionPane.showMessageDialog(null, "Servico deletado com sucesso");
                
        }catch (Exception e){
            System.out.println("Erro ao deletar servico " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao deletar servico!");
        }finally{
            this.conectar.fechaBanco();     
        }
    }
    
    public void LimparCampos(Servico novoServico)
    {
        txtDescricao.setText("");
        txtHoras.setText("");
        cbxEmpresa.setSelectedIndex(0);
        cbxFuncionario.setSelectedIndex(0);
        cbxServico.setSelectedIndex(0);
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane3 = new javax.swing.JScrollPane();
        txtEndCliente = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblImagem = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtConsultaServico = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        bttnCadastrarServico = new javax.swing.JButton();
        bttnBuscarServico = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        bttnAtualizarServico = new javax.swing.JButton();
        bttnApagarServico = new javax.swing.JButton();
        cbxServico = new javax.swing.JComboBox<>();
        cbxEmpresa = new javax.swing.JComboBox<>();
        cbxFuncionario = new javax.swing.JComboBox<>();
        txtHoras = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtDescricao = new javax.swing.JTextArea();
        bttnLimparServico = new javax.swing.JButton();

        txtEndCliente.setColumns(20);
        txtEndCliente.setRows(5);
        jScrollPane3.setViewportView(txtEndCliente);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Solicitação de Serviço");

        lblImagem.setBackground(new java.awt.Color(255, 255, 255));
        lblImagem.setForeground(new java.awt.Color(255, 255, 255));
        lblImagem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icon_servico.resized.png"))); // NOI18N
        lblImagem.setBorder(null);

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Selecione a empresa que irá contratar o serviço:");

        txtConsultaServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsultaServicoActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Selecione o prestador de serviço desejado:");

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Selecione o tipo de serviço que será prestado:");

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Faça uma breve descrição do serviço desejado:");

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Insira a quantidade de horas para o serviço:");

        bttnCadastrarServico.setText("Cadastrar serviço");
        bttnCadastrarServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnCadastrarServicoActionPerformed(evt);
            }
        });

        bttnBuscarServico.setText("Buscar");
        bttnBuscarServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnBuscarServicoActionPerformed(evt);
            }
        });

        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("Insira o CNPJ para buscar o serviço");

        bttnAtualizarServico.setText("Atualizar");
        bttnAtualizarServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnAtualizarServicoActionPerformed(evt);
            }
        });

        bttnApagarServico.setText("Apagar");
        bttnApagarServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnApagarServicoActionPerformed(evt);
            }
        });

        cbxServico.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Limpeza simples", "Limpeza completa", " " }));

        cbxEmpresa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));
        cbxEmpresa.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                cbxEmpresaAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        cbxEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxEmpresaActionPerformed(evt);
            }
        });

        cbxFuncionario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione" }));

        txtDescricao.setColumns(20);
        txtDescricao.setRows(5);
        jScrollPane4.setViewportView(txtDescricao);

        bttnLimparServico.setText("Limpar");
        bttnLimparServico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnLimparServicoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(txtConsultaServico, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(lblImagem, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(bttnBuscarServico, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bttnLimparServico, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bttnCadastrarServico)
                        .addGap(32, 32, 32)
                        .addComponent(bttnAtualizarServico, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(bttnApagarServico, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(cbxEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(cbxFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbxServico, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txtHoras, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(15, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6)
                                .addGap(175, 175, 175))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(294, 294, 294))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbxServico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(15, 15, 15)
                                        .addComponent(cbxEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel3)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbxFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(22, 22, 22)
                                        .addComponent(jLabel4))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(7, 7, 7)
                                        .addComponent(txtHoras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(28, 28, 28)
                                        .addComponent(jLabel5)
                                        .addGap(18, 18, 18)
                                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(lblImagem, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(75, 75, 75)
                .addComponent(jLabel11)
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttnBuscarServico)
                    .addComponent(txtConsultaServico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttnAtualizarServico)
                    .addComponent(bttnApagarServico)
                    .addComponent(bttnCadastrarServico)
                    .addComponent(bttnLimparServico))
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtConsultaServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsultaServicoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtConsultaServicoActionPerformed

    private void bttnCadastrarServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnCadastrarServicoActionPerformed
        this.CadastrarServico(novoServico);
        this.LimparCampos(novoServico);
    }//GEN-LAST:event_bttnCadastrarServicoActionPerformed

    private void bttnBuscarServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnBuscarServicoActionPerformed
        this.BuscarServico(novoServico);
    }//GEN-LAST:event_bttnBuscarServicoActionPerformed

    private void bttnAtualizarServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnAtualizarServicoActionPerformed
        this.AtualizarServico(novoServico); 
        this.LimparCampos(novoServico);
    }//GEN-LAST:event_bttnAtualizarServicoActionPerformed

    private void bttnApagarServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnApagarServicoActionPerformed
        this.DeletarServico(novoServico);
        this.LimparCampos(novoServico);
    }//GEN-LAST:event_bttnApagarServicoActionPerformed

    private void cbxEmpresaAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_cbxEmpresaAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxEmpresaAncestorAdded

    private void cbxEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxEmpresaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxEmpresaActionPerformed

    private void bttnLimparServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnLimparServicoActionPerformed
        this.LimparCampos(novoServico);
    }//GEN-LAST:event_bttnLimparServicoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UI_Servico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UI_Servico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UI_Servico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UI_Servico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UI_Servico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bttnApagarServico;
    private javax.swing.JButton bttnAtualizarServico;
    private javax.swing.JButton bttnBuscarServico;
    private javax.swing.JButton bttnCadastrarServico;
    private javax.swing.JButton bttnLimparServico;
    private javax.swing.JComboBox<String> cbxEmpresa;
    private javax.swing.JComboBox<String> cbxFuncionario;
    private javax.swing.JComboBox<String> cbxServico;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lblImagem;
    private javax.swing.JTextField txtConsultaServico;
    private javax.swing.JTextArea txtDescricao;
    private javax.swing.JTextArea txtEndCliente;
    private javax.swing.JTextField txtHoras;
    // End of variables declaration//GEN-END:variables
}
