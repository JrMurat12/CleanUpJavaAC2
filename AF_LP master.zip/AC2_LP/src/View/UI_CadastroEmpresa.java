/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;
import Objects.Empresa;
import Conexoes.MySQL;
import Objects.Funcionario;
import java.awt.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author alope
 */
public class UI_CadastroEmpresa extends javax.swing.JFrame {
  MySQL conectar = new MySQL ();
   Empresa novaEmpresa = new Empresa();
    /**
     * Creates new form UI_CadastroEmpresa
     */
    public UI_CadastroEmpresa() {
        initComponents();
    }
        private void CadastrarEmpresa(Empresa novaEmpresa){
        this.conectar.conectaBanco();
        
        novaEmpresa.setRazao(txtRazaoSocial.getText());
        novaEmpresa.setCNPJ(txtCNPJ.getText());
        novaEmpresa.setendereco(txtEndeEmpresa.getText());
        novaEmpresa.setcidade(txtCidadeEmpresa.getText());
        novaEmpresa.setUF((String)cbxUF.getSelectedItem());
        novaEmpresa.setcep(txtCEPEmpresa.getText());
        novaEmpresa.setTelefone(txtTelefoneEmpresa.getText());
        
    
    try {
                this.conectar.insertSQL ("INSERT INTO empresa ("
                + "razaoSocial,"
                + "cnpj,"
                + "endereco,"
                + "cidade,"
                + "uf,"
                + "cep,"
                + "telefone"
            + ") VALUES ("
                + "'" + novaEmpresa.getRazao() + "',"
                + "'" + novaEmpresa.getCNPJ() + "',"
                + "'" + novaEmpresa.getendereco() + "',"
                + "'" + novaEmpresa.getcidade() + "',"
                + "'" + novaEmpresa.getUF() + "',"
                + "'" + novaEmpresa.getcep() + "',"
                + "'" + novaEmpresa.getTelefone() + "'"
            + ");");
            
            JOptionPane.showMessageDialog(null, "Empresa cadastrado com sucesso");
        } catch (Exception e){
            System.out.println("Erro ao cadastrar empresa " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar empresa");
        } finally {
            this.conectar.fechaBanco();}
    }
    
private void BuscarEmpresa (Empresa novaEmpresa){
        this.conectar.conectaBanco();
        
        String consultaCnpj = this.txtConsultaCNPJ.getText();
        
        try {
            this.conectar.executarSQL(
                    "SELECT "
                    + "razaoSocial,"
                    + "cnpj,"
                    + "endereco,"
                    + "cidade,"
                    + "uf,"
                    + "cep,"
                    + "telefone"
                    + " FROM"
                        + " empresa"
                    + " WHERE"
                        + " cnpj = '" + consultaCnpj + "'" + ";");
            while (this.conectar.getResultSet().next()){
                novaEmpresa.setRazao(this.conectar.getResultSet().getString(1));
                novaEmpresa.setCNPJ(this.conectar.getResultSet().getString(2));
                novaEmpresa.setendereco(this.conectar.getResultSet().getString(3));
                novaEmpresa.setcidade(this.conectar.getResultSet().getString(4));
                novaEmpresa.setUF(this.conectar.getResultSet().getString(5));
                novaEmpresa.setcep(this.conectar.getResultSet().getString(6));
                novaEmpresa.setTelefone(this.conectar.getResultSet().getString(7));
            }
            
            if(novaEmpresa.getRazao() == ""){
                JOptionPane.showMessageDialog(null, "Empresa não encontrada!");
            }
        } catch (Exception e){
            System.out.println("Erro ao consultar empresa " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar empresa!");
        } finally{
            txtRazaoSocial.setText(novaEmpresa.getRazao());
            txtCNPJ.setText(novaEmpresa.getCNPJ());
            txtEndeEmpresa.setText(novaEmpresa.getendereco());
            txtCidadeEmpresa.setText(novaEmpresa.getcidade());
            cbxUF.setSelectedItem(novaEmpresa.getUF());
            txtCEPEmpresa.setText(novaEmpresa.getcep());
            txtTelefoneEmpresa.setText(novaEmpresa.getTelefone());
            this.conectar.fechaBanco();
        }
    }
    
    private void DeletarEmpresa (Empresa novaEmpresa){
        this.conectar.conectaBanco();
        
        String consultarCNPJ = this.txtConsultaCNPJ.getText();
        
        novaEmpresa.setRazao(txtRazaoSocial.getText());
        novaEmpresa.setCNPJ(txtCNPJ.getText());
        novaEmpresa.setendereco(txtEndeEmpresa.getText());
        novaEmpresa.setcidade(txtCidadeEmpresa.getText());
        novaEmpresa.setUF((String)cbxUF.getSelectedItem());
        novaEmpresa.setcep(txtCEPEmpresa.getText());
        novaEmpresa.setTelefone(txtTelefoneEmpresa.getText());
        
        if (novaEmpresa.getCNPJ().equals(" ")){
              JOptionPane.showMessageDialog(null,"CNPJ não informado");
        }
        
        try{
            this.conectar.deleteSQL(
                    "DELETE FROM empresa WHERE " + "cnpj = '" + consultarCNPJ + "'" + ";");
            JOptionPane.showMessageDialog(null, "Empresa deletada com sucesso");
                
        }
        catch (Exception e){
            System.out.println("Erro ao deletar empresa " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao deletar empresa!");
        }finally{
            this.conectar.fechaBanco();     
        }
    }
    public void AtualizarEmpresa(Empresa novaEmpresa){
        this.conectar.conectaBanco();
        
        String consultarCnpj = this.txtConsultaCNPJ.getText();
        
        novaEmpresa.setRazao(txtRazaoSocial.getText());
        novaEmpresa.setCNPJ(txtCNPJ.getText());
        novaEmpresa.setendereco(txtEndeEmpresa.getText());
        novaEmpresa.setcidade(txtCidadeEmpresa.getText());
        novaEmpresa.setUF((String)cbxUF.getSelectedItem());
        novaEmpresa.setcep(txtCEPEmpresa.getText());
        novaEmpresa.setTelefone(txtTelefoneEmpresa.getText());
        
        try{
            this.conectar.updateSQL(
                    "UPDATE empresa SET " + "razaoSocial = " + "'" + novaEmpresa.getRazao() + "',"
                    + "cnpj = " + "'" + novaEmpresa.getCNPJ() + "',"
                    + "endereco = " + "'" + novaEmpresa.getendereco() + "',"
                    + "cidade = " + "'" + novaEmpresa.getcidade() + "',"
                    + "uf = " + "'" + novaEmpresa.getUF() + "',"
                    + "cep = " + "'" + novaEmpresa.getcep() + "',"
                    + "telefone = " + "'" + novaEmpresa.getTelefone() + "'"
                    + " WHERE " + "cnpj = '" + consultarCnpj + "'" + ";");
            JOptionPane.showMessageDialog(null, "Empresa atualizado com sucesso");
                
        }catch (Exception e){
            System.out.println("Erro ao atualizar empresa " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao atualizar empresa!");
        }finally{
            this.conectar.fechaBanco();
        }
    }
    
    public void LimparCampos(Empresa novaEmpresa)
    {
        txtCNPJ.setText("");
        txtTelefoneEmpresa.setText("");
        txtCEPEmpresa.setText("");
        txtCidadeEmpresa.setText("");
        txtEndeEmpresa.setText("");
        txtRazaoSocial.setText("");
        cbxUF.setSelectedIndex(0);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtConsultaCNPJ = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtCidadeEmpresa = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtEndeEmpresa = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtCEPEmpresa = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cbxUF = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        txtCNPJ = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtTelefoneEmpresa = new javax.swing.JTextField();
        bttnCadastrarEmpresa = new javax.swing.JButton();
        bttnLimparEmpresa = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtRazaoSocial = new javax.swing.JTextField();
        bttnAtualizarEmpresa = new javax.swing.JButton();
        bttnApagarEmpresa = new javax.swing.JButton();
        bttnBuscarEmpresa = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Cadastro de Empresa");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 240, -1));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Razão Social");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 89, -1, -1));
        jPanel1.add(txtConsultaCNPJ, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 390, 153, -1));

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("CNPJ");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, -1, -1));
        jPanel1.add(txtCidadeEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 333, 181, -1));

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Endereço");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 228, -1, -1));
        jPanel1.add(txtEndeEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 250, 181, 49));

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Cidade");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 311, -1, -1));
        jPanel1.add(txtCEPEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(459, 182, 181, -1));
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(515, 89, -1, -1));

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("UF");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(459, 89, -1, -1));

        cbxUF.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO", "DF" }));
        jPanel1.add(cbxUF, new org.netbeans.lib.awtextra.AbsoluteConstraints(459, 112, 110, -1));

        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("CEP");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(459, 154, -1, -1));
        jPanel1.add(txtCNPJ, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 188, 181, -1));

        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Telefone");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(459, 228, -1, -1));
        jPanel1.add(txtTelefoneEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(459, 250, 181, -1));

        bttnCadastrarEmpresa.setText("Salvar");
        bttnCadastrarEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnCadastrarEmpresaActionPerformed(evt);
            }
        });
        jPanel1.add(bttnCadastrarEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(526, 321, 72, -1));

        bttnLimparEmpresa.setText("Limpar");
        bttnLimparEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnLimparEmpresaActionPerformed(evt);
            }
        });
        jPanel1.add(bttnLimparEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 390, 72, -1));

        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("CNPJ");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 367, -1, -1));
        jPanel1.add(txtRazaoSocial, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 111, 181, -1));

        bttnAtualizarEmpresa.setText("Atualizar");
        bttnAtualizarEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnAtualizarEmpresaActionPerformed(evt);
            }
        });
        jPanel1.add(bttnAtualizarEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 386, 89, -1));

        bttnApagarEmpresa.setText("Apagar");
        bttnApagarEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnApagarEmpresaActionPerformed(evt);
            }
        });
        jPanel1.add(bttnApagarEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(571, 386, 89, -1));

        bttnBuscarEmpresa.setText("Buscar");
        bttnBuscarEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnBuscarEmpresaActionPerformed(evt);
            }
        });
        jPanel1.add(bttnBuscarEmpresa, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 390, 72, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icon_empresa.resized.png"))); // NOI18N
        jLabel12.setText("jLabel12");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 100, 130));

        jLabel13.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("Cadastro de serviço >");
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bttnCadastrarEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnCadastrarEmpresaActionPerformed
    this.CadastrarEmpresa(novaEmpresa);
    this.LimparCampos(novaEmpresa);
    }//GEN-LAST:event_bttnCadastrarEmpresaActionPerformed

    private void bttnAtualizarEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnAtualizarEmpresaActionPerformed
        this.AtualizarEmpresa(novaEmpresa);
        this.LimparCampos(novaEmpresa);
    }//GEN-LAST:event_bttnAtualizarEmpresaActionPerformed

    private void bttnApagarEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnApagarEmpresaActionPerformed
        this.DeletarEmpresa(novaEmpresa);
        this.LimparCampos(novaEmpresa);
    }//GEN-LAST:event_bttnApagarEmpresaActionPerformed

    private void bttnBuscarEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnBuscarEmpresaActionPerformed
     this.BuscarEmpresa(novaEmpresa);
    }//GEN-LAST:event_bttnBuscarEmpresaActionPerformed

    private void bttnLimparEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnLimparEmpresaActionPerformed
        this.LimparCampos(novaEmpresa);
    }//GEN-LAST:event_bttnLimparEmpresaActionPerformed

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        UI_CadastroEmpresa fechar = new UI_CadastroEmpresa();
        dispose();

        UI_Servico abrir = new UI_Servico();
        abrir.setVisible(true);
    }//GEN-LAST:event_jLabel13MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UI_CadastroEmpresa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UI_CadastroEmpresa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UI_CadastroEmpresa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UI_CadastroEmpresa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UI_CadastroEmpresa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bttnApagarEmpresa;
    private javax.swing.JButton bttnAtualizarEmpresa;
    private javax.swing.JButton bttnBuscarEmpresa;
    private javax.swing.JButton bttnCadastrarEmpresa;
    private javax.swing.JButton bttnLimparEmpresa;
    private javax.swing.JComboBox<String> cbxUF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtCEPEmpresa;
    private javax.swing.JTextField txtCNPJ;
    private javax.swing.JTextField txtCidadeEmpresa;
    private javax.swing.JTextField txtConsultaCNPJ;
    private javax.swing.JTextField txtEndeEmpresa;
    private javax.swing.JTextField txtRazaoSocial;
    private javax.swing.JTextField txtTelefoneEmpresa;
    // End of variables declaration//GEN-END:variables
}
