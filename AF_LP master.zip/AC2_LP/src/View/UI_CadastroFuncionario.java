/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;
import Conexoes.MySQL;
import javax.swing.JOptionPane;
import Objects.Funcionario;

/**
 *
 * @author alope
 */
public class UI_CadastroFuncionario extends javax.swing.JFrame {

    MySQL conectar = new MySQL ();
    Funcionario novoFuncionario = new Funcionario();
    
        public UI_CadastroFuncionario() {
        initComponents();
    }
    
        private void CadastrarFuncionario(Funcionario novoFuncionario){
        this.conectar.conectaBanco();
        
        novoFuncionario.setnome(txtNomeFunc.getText());
        novoFuncionario.setCPF(txtCPFFunc.getText());
        novoFuncionario.setendereco(txtEndFunc.getText());
        novoFuncionario.setcidade(txtCidadeFunc.getText());
        novoFuncionario.setUF((String)cbxUF.getSelectedItem());
        novoFuncionario.setcep(txtCEPFunc.getText());
        novoFuncionario.setsexo((String)cbxSexoFunc.getSelectedItem());
        novoFuncionario.settelefone(txtTelefoneFunc.getText());
        
    
    try {
            this.conectar.insertSQL ("INSERT INTO funcionario ("
                + "nome, "
                + "cpf, "
                + "endereco, "
                + "cidade, "
                + "uf, "
                + "cep, "
                + "sexo, "
                + "telefone "
            + ") VALUES ("
                + "'" + novoFuncionario.getnome() + "',"
                + "'" + novoFuncionario.getCPF() + "',"
                + "'" + novoFuncionario.getendereco() + "',"
                + "'" + novoFuncionario.getcidade() + "',"
                + "'" + novoFuncionario.getUF() + "',"
                + "'" + novoFuncionario.getcep() + "',"
                + "'" + novoFuncionario.getsexo() + "',"
                + "'" + novoFuncionario.gettelefone() + "'"
            + ");");
            
            JOptionPane.showMessageDialog(null, "Funcionário cadastrado com sucesso");
        } catch (Exception e){
            System.out.println("Erro ao cadastrar funcioário " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar funcionário");
        } finally {
            this.conectar.fechaBanco();}
    }
    
    private void BuscarFuncionario (Funcionario novoFuncionario){
        this.conectar.conectaBanco();
        
        String consultaCpf = this.txtConsultaCPFFunc.getText();
        
        try {
            this.conectar.executarSQL(
                    "SELECT "
                    + "nome,"
                    + "cpf,"
                    + "endereco,"
                    + "cidade,"
                    + "uf,"
                    + "cep,"
                    + "telefone,"
                    + "sexo"
                    + " FROM"
                        + " funcionario"
                    + " WHERE"
                        + " cpf = '" + consultaCpf + "'" + ";");
            while (this.conectar.getResultSet().next()){
                novoFuncionario.setnome(this.conectar.getResultSet().getString(1));
                novoFuncionario.setCPF(this.conectar.getResultSet().getString(2));
                novoFuncionario.setendereco(this.conectar.getResultSet().getString(3));
                novoFuncionario.setcidade(this.conectar.getResultSet().getString(4));
                novoFuncionario.setUF(this.conectar.getResultSet().getString(5));
                novoFuncionario.setcep(this.conectar.getResultSet().getString(6));
                novoFuncionario.settelefone(this.conectar.getResultSet().getString(7));
                novoFuncionario.setsexo(this.conectar.getResultSet().getString(8));
            }
            
            if(novoFuncionario.getnome() == ""){
                JOptionPane.showMessageDialog(null, "Funcionario não encontrado!");
            }
        } catch (Exception e){
            System.out.println("Erro ao consultar funcionario " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao buscar funcionario!");
        } finally{
            txtNomeFunc.setText(novoFuncionario.getnome());
            txtCPFFunc.setText(novoFuncionario.getCPF());
            txtEndFunc.setText(novoFuncionario.getendereco());
            txtCidadeFunc.setText(novoFuncionario.getcidade());
            cbxUF.setSelectedItem(novoFuncionario.getUF());
            txtCEPFunc.setText(novoFuncionario.getcep());
            cbxSexoFunc.setSelectedItem(novoFuncionario.gettelefone());
            txtTelefoneFunc.setText(novoFuncionario.getsexo());
            this.conectar.fechaBanco();
        }
    }
    
    public void AtualizarFuncionario(Funcionario novoFuncionario){
        this.conectar.conectaBanco();
        
        String consultarCpf = this.txtConsultaCPFFunc.getText();
        
        novoFuncionario.setnome(txtNomeFunc.getText());
        novoFuncionario.setCPF(txtCPFFunc.getText());
        novoFuncionario.setendereco(txtEndFunc.getText());
        novoFuncionario.setcidade(txtCidadeFunc.getText());
        novoFuncionario.setUF((String)cbxUF.getSelectedItem());
        novoFuncionario.setcep(txtCEPFunc.getText());
        novoFuncionario.setsexo((String)cbxSexoFunc.getSelectedItem());
        novoFuncionario.settelefone(txtTelefoneFunc.getText());
        
        try{
            this.conectar.updateSQL(
                    "UPDATE funcionario SET " + "nome = " + "'" + novoFuncionario.getnome() + "',"
                    + "cpf = " + "'" + novoFuncionario.getCPF() + "',"
                    + "endereco = " + "'" + novoFuncionario.getendereco() + "',"
                    + "cidade = " + "'" + novoFuncionario.getcidade() + "',"
                    + "uf = " + "'" + novoFuncionario.getUF() + "',"
                    + "cep = " + "'" + novoFuncionario.getcep() + "',"
                    + "telefone = " + "'" + novoFuncionario.gettelefone() + "',"
                    + "sexo = " + "'" + novoFuncionario.getsexo() + "'"
                    + " WHERE " + "cpf = '" + consultarCpf + "'" + ";");
            JOptionPane.showMessageDialog(null, "Funcionario atualizado com sucesso");
                
        }catch (Exception e){
            System.out.println("Erro ao atualizar funcionario " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao atualizar funcionario!");
        }finally{
            this.conectar.fechaBanco();
        }
    }
    
    public void DeletarFuncionario(Funcionario novoFuncionario){
        this.conectar.conectaBanco();
        
        String consultarCpf = this.txtConsultaCPFFunc.getText();
        
        novoFuncionario.setnome(txtNomeFunc.getText());
        novoFuncionario.setCPF(txtCPFFunc.getText());
        novoFuncionario.setendereco(txtEndFunc.getText());
        novoFuncionario.setcidade(txtCidadeFunc.getText());
        novoFuncionario.setUF((String)cbxUF.getSelectedItem());
        novoFuncionario.setcep(txtCEPFunc.getText());
        novoFuncionario.setsexo((String)cbxSexoFunc.getSelectedItem());
        novoFuncionario.settelefone(txtTelefoneFunc.getText());
        
        try{
            this.conectar.deleteSQL(
                    "DELETE FROM funcionario WHERE " + "cpf = '" + consultarCpf + "'" + ";");
            JOptionPane.showMessageDialog(null, "Funcionario deletado com sucesso");
                
        }catch (Exception e){
            System.out.println("Erro ao deletar funcionario " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Erro ao deletar funcionario!");
        }finally{
            this.conectar.fechaBanco();     
        }
    }
    
    private void LimparCampos(Funcionario novoFuncionario){
        txtCPFFunc.setText("");
        txtCidadeFunc.setText("");
        txtEndFunc.setText("");
        txtNomeFunc.setText("");
        txtTelefoneFunc.setText("");
        txtCEPFunc.setText("");
        cbxSexoFunc.setSelectedIndex(0);
        cbxUF.setSelectedIndex(0);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtConsultaCPFFunc = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtCidadeFunc = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtEndFunc = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtCEPFunc = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cbxUF = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        txtCPFFunc = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        cbxSexoFunc = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        txtTelefoneFunc = new javax.swing.JTextField();
        bttnCadastrarFunc = new javax.swing.JButton();
        bttnBuscarFunc = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtNomeFunc = new javax.swing.JTextField();
        bttnAtualizarFunc = new javax.swing.JButton();
        bttnApagarFunc = new javax.swing.JButton();
        bttnLimparFuncionario = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Cadastro de Funcionário");

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Nome completo");

        txtConsultaCPFFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtConsultaCPFFuncActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("CPF");

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Endereço");

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Cidade");

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("UF");

        cbxUF.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO", "DF" }));
        cbxUF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxUFActionPerformed(evt);
            }
        });

        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("CEP");

        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("Sexo");

        cbxSexoFunc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione", "Feminino", "Masculino" }));

        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("Telefone");

        bttnCadastrarFunc.setText("Salvar");
        bttnCadastrarFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnCadastrarFuncActionPerformed(evt);
            }
        });

        bttnBuscarFunc.setText("Buscar");
        bttnBuscarFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnBuscarFuncActionPerformed(evt);
            }
        });

        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("CPF");

        bttnAtualizarFunc.setText("Atualizar");
        bttnAtualizarFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnAtualizarFuncActionPerformed(evt);
            }
        });

        bttnApagarFunc.setText("Apagar");
        bttnApagarFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnApagarFuncActionPerformed(evt);
            }
        });

        bttnLimparFuncionario.setText("Limpar");
        bttnLimparFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnLimparFuncionarioActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("Cadastro Empresa  >");
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("Voltar");

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/do-utilizador.1.png"))); // NOI18N
        jLabel13.setText("jLabel13");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(14, 14, 14))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(81, 81, 81)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(bttnCadastrarFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3)
                                            .addComponent(txtCidadeFunc, javax.swing.GroupLayout.DEFAULT_SIZE, 181, Short.MAX_VALUE)
                                            .addComponent(txtEndFunc)
                                            .addComponent(txtCPFFunc)
                                            .addComponent(txtNomeFunc))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel7)
                                                .addGap(72, 72, 72)
                                                .addComponent(jLabel6))
                                            .addComponent(cbxUF, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel8)
                                            .addComponent(txtCEPFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel9)
                                            .addComponent(cbxSexoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel10)
                                            .addComponent(txtTelefoneFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(82, 82, 82))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(txtConsultaCPFFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addComponent(bttnBuscarFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bttnLimparFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bttnAtualizarFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bttnApagarFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel14))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel1)
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cbxUF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNomeFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(21, 21, 21)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCPFFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCEPFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbxSexoFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTelefoneFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(228, 228, 228)
                        .addComponent(txtEndFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCidadeFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(39, 39, 39)
                .addComponent(bttnCadastrarFunc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addGap(3, 3, 3)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttnBuscarFunc)
                    .addComponent(txtConsultaCPFFunc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttnAtualizarFunc)
                    .addComponent(bttnApagarFunc)
                    .addComponent(bttnLimparFuncionario))
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbxUFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxUFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbxUFActionPerformed

    private void txtConsultaCPFFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtConsultaCPFFuncActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtConsultaCPFFuncActionPerformed

    private void bttnBuscarFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnBuscarFuncActionPerformed
        // TODO add your handling code here:
        this.BuscarFuncionario(novoFuncionario);
    }//GEN-LAST:event_bttnBuscarFuncActionPerformed

    private void bttnAtualizarFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnAtualizarFuncActionPerformed
        // TODO add your handling code here:
        this.AtualizarFuncionario(novoFuncionario);
        this.LimparCampos(novoFuncionario);
    }//GEN-LAST:event_bttnAtualizarFuncActionPerformed

    private void bttnApagarFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnApagarFuncActionPerformed
        // TODO add your handling code here:
        this.DeletarFuncionario(novoFuncionario);
        this.LimparCampos(novoFuncionario);
        txtConsultaCPFFunc.setText(" ");
    }//GEN-LAST:event_bttnApagarFuncActionPerformed

    private void bttnCadastrarFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnCadastrarFuncActionPerformed
        // TODO add your handling code here:
        this.CadastrarFuncionario(novoFuncionario);
        this.LimparCampos(novoFuncionario);
    }//GEN-LAST:event_bttnCadastrarFuncActionPerformed

    private void bttnLimparFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnLimparFuncionarioActionPerformed
        this.LimparCampos(novoFuncionario);
    }//GEN-LAST:event_bttnLimparFuncionarioActionPerformed

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        UI_CadastroEmpresa abrir = new UI_CadastroEmpresa();
        abrir.setVisible(true);
        
        UI_CadastroFuncionario fechar = new UI_CadastroFuncionario();
        dispose();
    }//GEN-LAST:event_jLabel12MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UI_CadastroFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UI_CadastroFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UI_CadastroFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UI_CadastroFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UI_CadastroFuncionario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bttnApagarFunc;
    private javax.swing.JButton bttnAtualizarFunc;
    private javax.swing.JButton bttnBuscarFunc;
    private javax.swing.JButton bttnCadastrarFunc;
    private javax.swing.JButton bttnLimparFuncionario;
    private javax.swing.JComboBox<String> cbxSexoFunc;
    private javax.swing.JComboBox<String> cbxUF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtCEPFunc;
    private javax.swing.JTextField txtCPFFunc;
    private javax.swing.JTextField txtCidadeFunc;
    private javax.swing.JTextField txtConsultaCPFFunc;
    private javax.swing.JTextField txtEndFunc;
    private javax.swing.JTextField txtNomeFunc;
    private javax.swing.JTextField txtTelefoneFunc;
    // End of variables declaration//GEN-END:variables
}
