/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objects;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author alope
 */
public class Empresa {
    private String razaoSocial;
    private String cnpj;
    private String endereco;
    private String cidade;
    private String uf;
    private String cep;
    private String telefone;

    public Empresa(String razaoSocial, String cnpj, String endereco, String cidade, String uf, String cep, String telefone ){
        razaoSocial = this.razaoSocial;
        cnpj = this.cnpj;
        endereco = this.endereco;
        uf = this.uf;
        cep = this.cep;
        telefone = this.telefone;
    }
    public Empresa(){}
    public void setCNPJ(String cnpj){
        this.cnpj = cnpj;
    }
    public String getCNPJ(){
        return(this.cnpj);
    }

    public void setRazao(String razaoSocial){
        this.razaoSocial = razaoSocial;
    }
    public String getRazao(){
        return(this.razaoSocial);
    }

    public void setendereco(String endereco){
        this.endereco = endereco;
    }
    public String getendereco(){
        return(this.endereco);
    }

    public void setcidade(String cidade){
        this.cidade = cidade;
    }
    public String getcidade(){
        return(this.cidade);
    }

    public void setUF(String uf){
        this.uf = uf;
    }
    public String getUF(){
        return(this.uf);
    }

    public void setcep(String cep){
        this.cep = cep;
    }
    public String getcep(){
        return(this.cep);
    }
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    public String getTelefone(){
        return(this.telefone);
    }

    public void LimparEmpresa(){
        this.razaoSocial = " ";
        this.endereco = " ";
        this.cidade = " ";
        this.uf = " ";
        this.cnpj = " ";
    }
    

}

