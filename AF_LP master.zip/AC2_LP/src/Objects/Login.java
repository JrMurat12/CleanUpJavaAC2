/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objects;

/**
 *
 * @author alope
 */
public class Login {
    
    private String user;
    private String senha;
    
    public Login(String user, String senha){
        user = this.user;
        senha = this.senha;
    }
    public Login(){}
    
    public void setUser(String user){
        this.user = user;
    }
    public String getUser(){
        return(this.user);
    }
    
    public void setSenha(String senha){
        this.senha = senha;
    }
    public String getSenha(){
        return(this.senha);
    }
    
}
